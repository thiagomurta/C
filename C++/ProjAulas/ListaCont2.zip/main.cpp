#include <iostream>
#include "ListaCont2.h"

int main()
{
    int n=40;


    ListaCont2 lista(n);

    for(int i=0; i<=n; i++)
    {
        lista.insereInicio(i+1);
        lista.imprime();
        lista.insereFinal(n - i);
        lista.imprime();
    }

    return 0;
}
